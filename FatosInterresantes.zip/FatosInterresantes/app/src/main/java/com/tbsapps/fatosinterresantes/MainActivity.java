package com.tbsapps.fatosinterresantes;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.firebase.analytics.FirebaseAnalytics;


import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    public static int counter=0;
    private InterstitialAd mInterstitialAd;
    private FirebaseAnalytics mFirebaseAnalytics;
    private fatos fatoss = new fatos();
    private cores coress = new cores();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /* ---------------------------------------------- */
        /* ADS Interstitial */
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("ca-app-pub-7088335280277526/6391974220");
        mInterstitialAd.loadAd(new AdRequest.Builder().build());

        ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
        scheduler.scheduleAtFixedRate(new Runnable() {
            public void run() {
                Log.i("TAG", "Interstitial working");
                runOnUiThread(new Runnable() {
                    public void run() {
                        if (mInterstitialAd.isLoaded()) {
                            mInterstitialAd.show();
                        } else {
                            Log.d("TAG", " Interstitial not loaded");
                        }
                    }
                });
            }
        }, 1, 1, TimeUnit.MINUTES);
        /* ----------------------------------------------- */

        // ADS BANNER
        AdView adView = (AdView) findViewById(R.id.adViewBottom);
        AdView adView2 = (AdView) findViewById(R.id.adViewTop);
        AdRequest adRequest = new AdRequest.Builder()
                .setRequestAgent("android_studio:ad_template").build();
        adView.loadAd(adRequest);
        adView2.loadAd(adRequest);
        /* ------------------------------------------ */


        ImageButton proximo = (ImageButton)findViewById(R.id.btn_proximo);
        proximo.setOnClickListener(new Proximo(this, (TextView) findViewById(R.id.factTextView), (RelativeLayout) findViewById(R.id.relativeLayout), proximo));
        ImageButton anterior = (ImageButton)findViewById(R.id.btn_anterior);
        anterior.setOnClickListener(new Anterior(this, (TextView) findViewById(R.id.factTextView), (RelativeLayout) findViewById(R.id.relativeLayout), anterior));
        ImageButton compartilhar = (ImageButton)findViewById(R.id.btn_share);
        compartilhar.setOnClickListener(new Compartilhar());
        Toast.makeText(this, "Seja bem-vindo!!", 1).show();

    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        /* COMPARTILHAR */
        switch (item.getItemId()) {
            case R.id.btn_share:
                Intent compartilhar = new Intent(Intent.ACTION_SEND);
                compartilhar.setType("text/plain");
                compartilhar.putExtra(Intent.EXTRA_TEXT, "Fatos Interresantes! https://play.google.com/store/search?q=TECHHUBINDIAN");
                startActivity(Intent.createChooser(compartilhar, "Compartilhe com"));
                break;
        }
        Toast.makeText(getApplicationContext(), "Você clicou em compartilhar!", Toast.LENGTH_SHORT).show();
        return super.onOptionsItemSelected(item);

    }

    final class Compartilhar implements  View.OnClickListener {
        @Override
        public final void onClick(View view) {
            Intent compartilhar = new Intent(Intent.ACTION_SEND);
            compartilhar.setType("text/plain");
            compartilhar.putExtra(Intent.EXTRA_TEXT, "Fatos Interresantes! https://play.google.com/store/search?q=TECHHUBINDIAN");
            startActivity(Intent.createChooser(compartilhar, "Compartilhe com"));
        }
    }
    static final class Proximo implements View.OnClickListener {
        final TextView TV;
        final RelativeLayout RL;
        final ImageButton IB;
        final MainActivity MA;

        Proximo(MainActivity mainActivity, TextView textView, RelativeLayout relativeLayout, ImageButton button) {
            this.MA = mainActivity;
            this.TV = textView;
            this.RL = relativeLayout;
            this.IB = button;
        }

        public final void onClick(View view) {
            counter++;
            fatos a = this.MA.fatoss;
            if(counter > a.todosf.length-1) counter=a.todosf.length-1;
            {
                this.TV.setText(a.todosf[counter]);
            }
//            cores b = this.MA.coress;
//            int parseColor = Color.parseColor(b.todasc[new Random().nextInt(b.todasc.length)]);
//            this.RL.setBackgroundColor(parseColor);
            /*  this.IB.setTextColor(parseColor); */
        }
    }

    static final class Anterior implements View.OnClickListener {
        final TextView TV;
        final RelativeLayout RL;
        final ImageButton IB;
        final MainActivity MA;

        Anterior(MainActivity mainActivity, TextView textView, RelativeLayout relativeLayout, ImageButton button) {
            this.MA = mainActivity;
            this.TV = textView;
            this.RL = relativeLayout;
            this.IB = button;
        }

        public final void onClick(View view) {
            counter--;
            fatos a = this.MA.fatoss;
            if(counter < 0) counter= 0;
            {
                this.TV.setText(a.todosf[counter]);
            }
//            cores b = this.MA.coress;
//            int parseColor = Color.parseColor(b.todasc[new Random().nextInt(b.todasc.length)]);
//            this.RL.setBackgroundColor(parseColor);
            /*  this.IB.setTextColor(parseColor); */
        }
    }

    public static final class fatos {
        public String[] todosf = new String[]{
                "A sede da LEGO na Dinamarca contém um cofre subterrâneo e com temperatura controlada para guardar todas as peças já produzidas pela empresa",
                "Abacates não costumam amadurecer nas árvores, então quando o plantio não conta com aves e outros animais que possam comer os frutos, é possível armazenar algumas espécies de abacates nas árvores mesmo, durante um bom tempo",
                "O empresário de Elvis Presley criou broches que diziam “Eu odeio o Elvis” para vender e, assim, ganhar dinheiro das pessoas que não estavam comprando os álbuns do cantor",
                "Todos os pandas do mundo pertencem à China. O aluguel dos animais rende cerca de US$ 1 milhão por ano",
                "Ossos encontrados nas Ilhas Seymour nos mostram que, há quase 40 milhões de anos, pinguins mediam mais de 1,80 m de altura e pesavam quase 115 kg",
                "Tsundoku é o ato de comprar livros, mas não lê-los",
                "Na França, os supermercados não podem jogar comidas fora. Ou eles reciclam os itens, ou doam os alimentos que estão próximos ao vencimento para instituições de caridade",
                "Corvos podem aprender a falar melhor do que papagaios",
                "Formigas se espreguiçam quando acordam pela manhã.",
                "Cachorros conseguem compreender até 250 palavras e gestos. Um cachorro médio é tão esperto quanto uma criança de dois anos",
                "Avestruzes podem correr mais rápido do que cavalos.",
                "Medalhas de ouro olímpicas são feitas, em sua maior parte, de prata.",
                "Você nasce com 300 ossos, mas quando se torna um adulto possui apenas 206.",
                "Demora cerca de 8 minutos para a luz do Sol atingir a Terra.",
                "Bamboos podem crescer cerca de 1 metro em apenas 1 dia.",
                "O estado da Flórida é maior que a Inglaterra.",
                "Alguns pinguins podem pular cerca de 2-3 metros para fora da água.",
                "Em média são necessários 66 dias para se formar um novo hábito.",
                "Mamutes ainda andavam na Terra quando a Grande Pirâmide foi construída.",
                "A comida mais roubada no mundo é o queijo, com 4% do queijo produzido sendo roubado.",
                "Jurassic World agora(2015) possui o recorde de maior estréia na história do cinema.",
                "Chuck Palahniuk, autor de Clube da Luta, prefere a versão do filme do que seu próprio livro.",
                "O Toyota Supra que Brian dirige no fim de Velozes e Furiosos 7 pertencia ao falecido ator Paul Walker.",
                "A idéia para o filme Centopéia Humana foi de uma piada sobre como pedófilos deviam ser punidos.",
                "O time Pixxar teve a idéia para os filmes WALL-E, Vida de Inseto e Monstros S.A. durante o mesmo almoço.",
                "Existe um livro chamado 'Se tornando o Batman: A Possibilidade de um Super Herói' escrito por um neurocientista, e que cobre em detalhes o quanto uma pessoa comum precisaria estudar e treinar para se tornar o Batman.", "O Expresso Hogwarts dos filmes de Harry Potter é na verdade um trem real na Escócia e não um trem gerado por computação gráfica.",
                "James Cameron era sem-teto quando escreveu 'O Exterminador', e vendeu os direitos por 1 real, nas condições de que ele fosse o diretor do filme.",
                "Stephen Hawking é a única pessoa a se colocar dentro do universo Star Trek.", "Em Tunisia você pode reservar uma noite na casa de infância de Luke Skywalker por apenas 10 dólares.",
                "Caso você ainda não se sinta velho, lembre-se que o Rei Leão foi lançado a 19 anos atrás. De nada.", "Batman já venceu o Superman mais de uma vez.",
                "4 de Maio é o dia anual de Star Wars.", "Mickey Mouse foi o primeiro não-humano a ganhar um Oscar.",
                "Space Jam é o filme mais famoso de basketball no mundo todo.", "Pumbaa, de Rei Leão, foi o primeiro personagem que soltou gases em um filme da Disney.",
                "A fala mais comum em filmes americanos é: 'Let's get out of here'.", "São necessários cerca de 9 milhões de balões para levantar uma casa como no filme UP.",
                "Chorar literalmente alivia o estresse e ajuda os humanos a diminuir os sentimentos de raiva e tristeza.",
                "Pesquisas da NASA dizem que a soneca perfeita é de 26 minutos.",
                "Gases que foram segurados podem entrar na sua corrente sanguínea e fazer mal para o seu corpo.",
                "Em um período de 3-5 anos, a falta de sono pode encolher o seu cérebro.",
                "Músculos humanos são limitados por nosso cérebro por segurança, na verdade o ser humano tem a força para levantar ate carros.",
                "Em média, jogadores de futebol correm cerca de 15km em uma única partida.",
                "James Watson, um dos cientistas que descobriu a estrutura em hélice do DNA, acreditava que a estupidez era uma doença que pode ser curada.",
                "Cerca de 25% dos homens russos morrem antes de alcançar os 50 anos, normalmente por causa do excesso de vódica.",
                "Algodão doce, que faz bastante mal para os dentes, foi inventado por um dentista.", "Melancias ajudam a diminuir o estresse e a ansiedade.",
                "Em média, pessoas que reclamam vivem mais - Liberar a tensão aumenta a imunidade do corpo e melhora a saúde.",
                "Solidão é processada pela mesma parte do cérebro que a dor física.",
                "Sonecas diárias ajudam a melhorar a memória e diminuem o risco de doenças do coração.",
                "Londres possui um 'Cereal Café' onde você pode comer centenas de tipos diferentes de cereais de todo o mundo.",
                "Um restaurante gratuito e operado por voluntários na Índia serve cerca de 100.000 refeições por dia e tem existido por mais de 300 anos.",
                "O Japão possui morangos chamados de 'Essência do Primeiro Amor' que são completamente brancos por dentro e com sementes vermelhas.",
                "Americanos em média comem cerca de 18 acres de pizza por dia.", "70% dos temperos usados no mundo são produzidos em um único pais: Índia.",
                "A Terra, vista da lua, também passa por fases.",
                "Um 'butt', que pode ser traduzido como 'bunda', já foi uma unidade de medida para vinhos na Inglaterra Medieval.",
                "Os ventriloquistas que animaram os raptors em Jurassica Park tiveram que participar de um curso de 6 semanas sobre como se mover como um dinossauro.",
                "De acordo com estudos, Twitter e Facebook são mais dificeis de resistir do que o álcool.", "A universidade de Oxford é mais antiga do que o Império Asteca.",
                "O bolso menor dentro do bolso das calças foi feito especialmente para relógios de bolso.",
                "O famoso som inicial do Windows, que toca toda vez que máquina é ligada, foi feito usando um MAC.",
                "No espaço não é possível chorar por que não existe gravidade para fazer as lágrimas cairem.",
                "Mais pessoas falam inglês na China do que nos Estados Unidos.",
                "Baleias Azuis são tão grandes que uma criança consegue nadar dentro de suas veias.",
                "Mulheres acham homens mais atrativos quando eles estão recebendo a atenção de outras mulheres.",
                "Homens são os únicos mamíferos que atrasam o sono por vontade própria.",
                "Existem chuvas de diamantes em Saturno e Júpiter.",
                "Ratos não conseguem vomitar, é por isso que o veneno de ratos funciona.",
                "Depois da queda do império Romano, a tecnologia para fazer concreto ficou perdida por mais de 1000 anos.",
                "Você pode mudar sua linguagem no facebook para 'Pirata'.",
                "Todas as bactérias existentes no corpo humano pesam juntas cerca de 4kg.",
                "Não é ilegal fazer topless no centro da cidade de Nova York.",
                "Mais pessoas cometem suicídio do que são assassinadas em Nova York.",
                "Os esquilos plantam milhares de árvores ao se esquecer de onde enterraram suas sementes.",
                "Os pinguins do gênero Pygoscellis propõem o casamento ás fêmeas dando uma pedrinha de presente.",
                "As marcas no nariz de cães são como as digitais para os humanos, pois cada cão tem o seu próprio padrão.",
                "Cherophobia é o medo de diversão.",
                "A saliva humana tem um ponto de ebulição três vezes maior que a água.",
                "Uma águia consegue matar uma criança e carregá-la durante o voô.",
                "Ursos polares conseguem comer mais de 50 pinguins em uma única refeição.",
                "Não é possível roncar e sonhar ao mesmo tempo.",
                "Uma ovelha, um pato e um galo foram os primeiros passageiros de um balão de ar quente.",
                "Facebook, Skype e Twitter são banidos na China.",
                "Cerca de 95% das pessoas escrevem coisas que nunca diriam pessoalmente em mensagens de texto.",
                "O Titanic foi o primeiro navio a usar o sinal de SOS.",
                "Cerca de 8.000 americanos se machucam com instrumentos musicais cada ano.",
                "A língua francesa tem cerca de 17 palavras diferentes para 'se render'.",
                "Lontras marinhas dormem de mãos dadas para não serem separadas pela correnteza.",
                "J.K. Rowling escolheu o nome Hermione pelo fato de ser um nome incomum, dessa forma as garotas poderiam se identificar melhor com a personagem.",
                "Os testículos do polvo estão localizados na cabeça.",
                "O primeiro despertador só podia tocar as 4:00 am.",
                "Pássaros não urinam.", "Lesmas possuem 4 narizes.",
                "A Bíblia é o livro mais roubado das lojas no mundo todo.", "De acordo com Gêneses 1:20-22, a galinha veio antes de ovo.",
                "Esquilos se esquecem de onde esconderam mais da metade de suas nozes.",
                "Porcos-espinhos flutuam na água.",
                "Para cara página 'normal' na web existem pelo menos 5 páginas de pornografia.",
                "Minhocas possuem 5 corações.", "Um humano normal perde cerca de 200 fios de cabelo por dia.",
                "Estrelas-do-mar não possuem cérebro.",
                "Crianças crescem mais rápido na primavera.",
                "Venus é o único planeta que rotaciona em sentido horário.",
                "Em Kentucky é ilegal carregar sorvete no seu bolso traseiro.",
                "Uma libélula possui um tempo de vida de 24 horas.",
                "Nepal é o único país que não possui uma bandeira retangular.",
                "Um leão na vida selvagem normalmente não mata mais que 20 vezes por ano.",
                "Os dentes de um tubarão são literalmente mais fortes do que aço.",
                "O nome da filha mais nova de Walt Disney é Sharon.",
                "Catoptrophobia é o medo de espelhos.",
                "Crocodilos possuem a mordida mais forte no reino animal.",
                "Cerca de 8% das pessoas possuem uma costela extra.",
                "O leite dos camelos nunca fica coalhado.",
                "Cavalos marinhos formam pares para o resto da vida e quando nadam juntos não se largam, se segurando pela cauda.",
                "Esquilos adotam bebês esquilos que eles encontram abandonados.",
                "Cerca de 33% das mulheres mentem sobre o peso que possuem.",
                "O número de nascimentos na Índia por ano é maior que a população inteira da Austrália.",
                "De acordo com o Código de Hammurabi, a pena por erros médicos é cortar as duas mãos do médico.",
                "o chocolate é considerado a comida preferida das mulheres.",
                "A baleia azul pode passar 6 meses sem comer.",
                "Cerca de 82% das pessoas acreditam em vida após a morte.",
                "A pele dos seus lábios é 200 vezes mais sensível do que a dos seus dedos.",
                "O caracol consegue andar sobre uma lâmina afiada sem se cortar.",
                "The Flash possui o soco mais forte registrado nas histórias em quadrinho.",
                "Com a pressão certa a água pode cortar até metal.",
                "Em Scituate - Rhode Island, é ilegal manter galinhas dentro de casa se você vive em um trailer.",
                "O dinossauro mais antigo encontrado é o Eoraptor, que viveu 230 milhões de anos atrás onde agora é a Argentina.",
                "O filme 'Melhor é impossível' foi traduzido como 'Sr. Cocô de Gato' na China.", "Os árabes foram os primeiros a torrar o café.",
                "Cervos dão seu primeiro passo meia hora depois do nascimento.",
                "A lagarta tem mais de 2000 músculos.",
                "Existe um lago embaixo da Antártica que tem mais de 25 milhões de anos de idade e é chamado de Lago Vostok.",
                "Friggatriskaidekaphobia é o medo de Sextas-Feiras 13.", "Coelhos não podem vomitar.",
                "O sistema de democracia foi introduzido 2500 anos atrás, em Athenas na Grécia.",
                "O coco é considerado a maior semente do mundo.", "Um vento com uma velocidade superior a 119 km é considerado um furacão.",
                "Uma formiga, quando intoxicada, sempre vai cair com o lado direito no chão.",
                "No colegial, Robin Williams foi votado como 'O que tem menos chances de vencer na vida'.",
                "Seriam necessários 15,840,000 rolos de papel para cobrir a Grande Muralha da China.",
                "Elefantes se comunicam com ondas sonoras que possuem uma frequência mais baixa do que humanos podem ouvir.",
                "O peso pode afetar a habilidade da mulher de dar a luz.",
                "O som viaja 10 vezes mais rápido pelo granito do que pelo ar.",
                "O campo de visão de uma pessoa é de 180 graus.",
                "Dinheiro em papel foi usado pela primeira vez na China.",
                "O mineral mais macio conhecido é o talco.", "Café é a bebida mais consumida no mundo, com 400 bilhões de copos sendo consumidos por ano.",
                "Itália e França produzem 40% de todo o vinho no mundo.", "Banana é a fruta mais consumida na América.",
                "Se você manter os seus olhos abertos por muito tempo sem piscar eles vão sair pra fora das órbitas.",
                "Todo ano, cerca de 98% dos átomos do seu corpo são substituídos.",
                "Insetos também tremem quando sentem frio.",
                "Algumas espécies de dinossauro eram do tamanho de galinhas.",
                "Todos os 3 fundadores da Apple trabalharam na Atari antes de formar a Apple.",
                "Algumas minhocas vão comer elas mesmas se não conseguirem achar nenhuma comida.",
                "Americanos usam cerca de 1000 toneladas de folhas de chá todo o ano.", "Em 1790 apenas 5% da população americana vivia em cidades.",
                "Raios de sol que brilham através das nuvens são chamados de 'Chuva crepuscular'",
                "Um lápis comum geralmente pode escrever cerca de 50.000 palavras.", "Zoophobia é o medo de animais.",
                "O coletivo de sapos é Saparia.",
                "O pé de um humano adulto tem 26 ossos.",
                "A gazela é um antílope.",
                "O Coringa não possui um nome, nenhuma das diversas origens do personagem existentes nas histórias em quadrinhos é considerada a verdadeira.",
                "Red Richards, o Sr. Fantástico, é considerado o terrestre mais inteligente no universo Marvel.",
                "Só 1 pessoa em 2 bilhões vai viver até os 116 anos.", "Existe uma cidade chamada Roma em cada continente.",
                "Não existem dois leões com o mesmo padrão de bigodes, é como uma digital pra eles.",
                "Existem mais de 1.600 espécies de estrela-do-mar no mundo.",
                "A primeira fotografia aérea foi tirada de um balão nos Estudos Unidos, durante a guerra civil.",
                "Seu polegar da mão é aproximadamente do tamanho do seu nariz.", "Persia mudou seu nome para Iran em 1935.",
                "Ursos polares usam o gelo como uma plataforma para caçar focas na água.",
                "A capital da Coréia, Seoul, significa literalmente 'Capital'.",
                "Vacinas de gripe normalmente funcionam apenas 70% das vezes.",
                "A única vez registrada que nevou no Deserto do Sahara foi em 18 de Fevereiro de 1979.",
                "Seu coração bate mais de 100.000 vezes por dia.", "Nós piscamos em média 25 vezes por minuto.",
                "O canguru vermelho da Austrália pode pular 8 metros em 1 pulo.", "É impossível lamber a própria sobrancelha.",
                "O maior palácio no mundo é o Palácio Imperial no centro de Peking.", "Jamaica Blue Mountain é considerado o melhor café do mundo.",
                "Em média, nós piscamos cerca de 20 milhões de vezes por ano.",
                "Um polvo possui 3 corações.",
                "É ilegal pronunciar errado a palavra 'Arkansas' no estado de Arkansas.",
                "Homens tem mais casos de soluços do que as mulheres.",
                "Apenas mosquitos fêmeas picam.",
                "Agosto tem a maior porcentagem de nascimentos.",
                "A maioria dos esquimós não vive em iglus.",
                "O coração de um humano adulto pesa em média 283 gramas.",
                "Cerca de 1/10 da superfície da Terra é coberta permanentemente por gelo.",
                "Sherlock Holmes não costumava dizer 'Elementar, meu caro Watson'.",
                "Gatos são os únicos animais que ronronam.",
                "Atualmente o mundo tem cerca de 5 bilhões de habitantes, esse número tem previsão de aumentar para 15 bilhões em 2080.",
                "Para escapar da boca de um crocodilo, aperte seus dedos contra os olhos dele, isso vai te livrar da mordida instantaneamente.",
                "Mercúrio é o único metal que é liquido em temperatura ambiente.",
                "Barbas loiras crescem mais rápido do que as morenas.",
                "Paris significa 'as pessoas que trabalham'.",
                "Elásticos duram mais quando são refrigerados.",
                "Coca diet foi introduzida em 1982.",
                "Os U.S. Post Office são responsáveis por 43% de todo o correio do mundo.",
                "Humanos são os únicos animais que usam o sorriso como uma resposta emocional.",
                "Pessoas em praias de nudismo costumam jogar mais volêi do que qualquer outro esporte.",
                "O isqueiro foi inventado antes dos palitos de fósforo.",
                "Existem 10 trilhões de células vivas dentro do corpo humano.",
                "Apenas 1% das bactérias causam doenças.",
                "Regulus é a estrela mais brilhante da constelaçao de Leão.",
                "Até o século 19, folhas de chá eram usadas como dinheiro na Sibéria.",
                "Peter Parker, o Homem-Aranha, já fez um pacto com o demônio nas histórias em quadrinho da Marvel.",
                "A Estatua da Liberdade chegou em Nova York em 1885, a bordo do navio Francês 'Isere'.",
                "A Mona Lisa não possui sobrancelhas, raspá-las era uma moda na época.",
                "Cerca de 21% das pessoas no mundo não arrumam a cama quando se levantam.",
                "Ursos polares possuem um excelente senso olfativo, podendo detectar focas a mais de 1km de distância.",
                "Plantações de café produzem sua primeira safra com 5 anos de idade.",
                "1 googol é o numero 1 seguido de 100 zeros.",
                "É impossível espirrar e manter apenas um olho aberto ao mesmo tempo.",
                "Baleias não conseguem focar os dois olhos no mesmo objeto ao mesmo tempo.",
                "O Brasil produz cerca de 1/3 de toda a produção de café do mundo.",
                "Castores podem segurar a respiração por 45 minutos.",
                "Mulher Maravilha foi a primeira heroína criada nos quadrinhos.",
                "Mulher Maravilha foi apresentada em All Star Comics, em Dezembro do ano de 1941.",
                "Mulher Maravilha foi criada pelo psicologista William Mouton Marston.",
                "Iowa é o estado que mais possui companhias de telefone independentes no mundo.",
                "A sigla Laser significa 'Light Amplification by Stimulated Emission of Radiation', e pode ser traduzida como 'Amplificação de Luz por Emissão de Radiação Estimulada.'",
                "Humanos possuem menos músculos que uma lagarta.",
                "Leonardo da Vinci foi o inventor das tesouras.",
                "Todos os bebês não conseguem enxergar cores quando nascem.",
                "Elefantes são herbívoros e podem gastar cerca de 16 horas por dia coletando folhas e raízes.",
                "Suco de laranja ajuda o corpo a absorver o ferro mais facilmente quando é consumido durante a refeição.",
                "Xenophobia é o medo de extrangeiros.",
                "Alface é o vegetal verde mais popular do mundo.",
                "A escritora de mistérios Agatha Christie adquiriu seu extenso conhecimento sobre venenos enquanto trabalhava em um hospital na Primeira Guerra Mundial.",
                "O primeiro coração artificial foi patenteado por Paul Winchell em 1963.",
                "Libélulas possuem 6 pernas, mas não são capazes de andar.",
                "Em média, uma pessoa precisa de 1.792 passos para chegar ao topo da Torre Eiffel.",
                "Pandas gigantes possuem um tempo de vida de 20 anos na vida selvagem.",
                "Bananas não possuem gordura.",
                "Estudos provaram que é mais difícil de contar uma mentira convincente para alguém que você acha sexualmente atraente.",
                "Em média porcos-espinhos possuem 30.000 espinhos.", "Mulheres são 37% mais suscetivas a irem ao psiquiatra do que os homens.",
                "O nome do imperador Genghis Khan era na verdade Temujin.",
                "O DNA de um humano possui uma semelhança de 70% com uma lesma.",
                "Cerca de 97% de todo o dinheiro em papel dos Estados Unidos contém traços de cocaína.",
                "As notas 5 e de 50 são feitas de plástico na Austrália.",
                "O coração do rato bate 650 vezes por minuto.",
                "Phobophobia é o medo de ter medo.",
                "Uma espécie de antílope, os Sitatungas, podem dormir debaixo da água.",
                "Chipre tem um mapa em sua bandeira.",
                "O fogo se move mais rápido para cima do que para baixo.",
                "Coca Cola é originalmente verde.",
                "Alguns bebês girafas possuem mais que 2 metros de altura quando nascem.",
                "Campanologia é o estudo de sinos.",
                "Bebês podem sonhar mesmo antes de nascer.",
                "Espanha é a maior fonte de turismo no mundo.",
                "A maioria dos pinguins vive no emisfério Sul.",
                "Cangurus não podem andar para trás.",
                "7 pessoas no mundo ja foram atingidas por fragmentos de meteoritos.",
                "Neil Armstrong pisou na lua com seu pé esquerdo primeiro.",
                "Formigas trabalhadoras vivem por cerca de 7 anos e a rainha por cerca de 15 anos.",
                "Na Austrália é comum servir panquecas no café da manhã, no almoço e no jantar.",
                "Em média uma galinha bota cerca de 260 ovos por ano.",
                "O primeiro beijo em um filme foi entre May Irwin e John Rice no filme The Widow Jones, em 1896.",
                "Um canguru não pode pular sem que sua calda esteja tocando o chão.",
                "Papagaios, a ave falante mais famosa no mundo, dificilmente aprende mais do que 20 palavras em sua vida.",
                "Usuários de computador piscam cerca de 20 vezes por minuto.",
                "O porco mais velho no mundo viveu até a idade de 68 anos.",
                "Albert Einstein não gostava de usar meias.",
                "Egípcios dormiam em travesseiros feitos de pedra.",
                "Thomas Edison possuia uma coleção de mais de 5.000 passáros.",
                "China baniu viagens no tempo na TV, dizendo que isso desrespeita a história.",
                "Neurologistas possuem uma teoria de que toda vez que você resiste à sua raiva você está treinando seu cérebro pra ser mais calmo e mais amável.",
                "Cerca de 15% dos usuários de iPhone usam o seu dispositivo com a tela quebrada.",
                "O filme que fez menos sucesso de Harry Potter fez 90 milhões de dólares a mais do que o filme que fez mais sucesso da saga Crepúsculo.",
                "Todos os filmes de Harry Potter estão na lista dos 50 melhores filmes de todas as épocas.",
                "J.K. Rowling escreveu o último capítulo o último livro de Harry Potter 7 anos antes de lançar o primeiro livro.",
                "A atriz Shirley Henderson que fazia a Murta que geme nos filmes de Harry Potter era na verdade uma mulher de 46 anos de idade.",
                "Harry Potter agora(2015) tem 34 anos de idade.",
                "Nos filmes de Harry Potter, o patrono de Hermione é uma lontra.",
                "Nos filmes de Harry Potter, o patrono de Ron é um Jack Russell terrier, que é conhecido por perseguir lontras. O patrono de Hermione é uma lontra.",
                "J.K. Rownling queria que Harry Potter ficasse com a Hermione no fim da história.",
                "Daniel Radcliffe foi apelidado de 'Harry Chaminé' no set de filmagens por que possuía o hábito de fumar mais de 20 cigarros por dia.",
                "Os pais de Daniel Radcliffe permitiram que ele ficasse acordado meia hora mais tarde como uma comemoração quando descobriram que ele tinha conseguido o papel de Harry Potter.",
                "J.K. Rownling considerava matar Ronny Weasley mas felizmente decidiu que era melhor para história ele viver.",
                "Todos os livros no escritório do Dumbledore nos filmes de Harry Potter são apenas páginas amareladas sem nada escrito.",
                "Daniel Radcliffe usou um total de 160 pares de óculos durante as filmagens de Harry Potter.",
                "Maggie Smith (Professora McGonagall) lutava contra o câncer quando filmava o último filme de Harry Potter, ela gravou mesmo assim por que ela não queria desapontar os fãs dos filmes. Felizmente ela se recuperou totalmente no ano seguinte.",
                "Depois do último filme de Harry Potter, abrigos de animais foram obrigados a lidar com centenas de corujas abandonadas por seus donos.",
                "Os dementadores nos filmes de Harry Potter foram inspirados na depressão da autora.",
                "J.K. Rownling está escrevendo uma oitava história para Harry Potter.",
                "Enxaqueca de Hogwarts é um termo média que realmente existe, é usado quando uma pessoa fica com dor de cabeça por ler por uma grande quantidade de tempo sem parar.",
                "Antigamente era necessário 1 ano para vender 10 milhões de iPhones, no ano passado a Apple vendeu isso em apenas 1 final de semana.",
                "Cerca de 65% dos usuários de smartphones não baixam nenhum aplicativo por mês.",
                "Google Maps calcula o tráfico rastreando o quão rápido dispositivos Android estão se movendo na estrada.",
                "Apenas 5% dos usuário do Twitter possuem mais de 100 seguidores.",
                "Google fundou a empresa Calico, uma companhia focada inteiramente em 'curar a morte'.",
                "Os fones Mico são capazes de ler as ondas do seu cérebro e selecionar uma música baseada em como você está se sentindo no momento.",
                "Apenas 8% do dinheiro no mundo é físico, o resto existe apenas em computadores.", "Samsung é também uma empresa de armas de fogo.",
                "Se o olho humano fosse uma câmera digital ele teria 576 megapixels.",
                "Terrafugia é o primeiro carro voador do mundo."
        };
    }

    public static final class cores {
        public String[] todasc = new String[]{"#39add1", "#3079ab", "#c25975", "#e15258", "#f9845b", "#838cc7", "#7d669e", "#53bbb4", "#51b46d", "#e0ab18", "#637a91", "#f092b0", "#b7c0c7", "#FFFFFF", "#FFD700", "#B8860B", "#FF0000", "#006400", "#9400D3", "#191970"};
    }
}